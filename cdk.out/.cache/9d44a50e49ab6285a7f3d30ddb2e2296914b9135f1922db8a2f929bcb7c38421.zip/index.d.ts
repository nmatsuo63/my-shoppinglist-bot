import * as Lambda from 'aws-lambda';
export declare const handler: Lambda.APIGatewayProxyHandler;
